# LOTUS DIGITAL MIXER — Android Core V1.0

Starter project for an 8-channel Android audio mixer, targeting ASUS ROG Phone 2 + Maono PS22.

## What this project contains
- Kotlin Android app shell with an 8-channel mixer UI.
- Native C++ audio engine using Oboe (AAudio/OpenSL ES backend selection handled by Oboe).
- 8 virtual mixer channels, stereo master, per-channel gain/pan/mute/solo.
- Basic 3-band tone shaping and compressor parameters in the native channel API (live input currently feeds CH1).
- Real-time input-to-mixer-to-output processing.
- Audio device enumeration in native Oboe layer.

## Important limitations
- This is source code, not a prebuilt/verified APK. Build it in Android Studio.
- USB audio routing depends on the Android version, USB host mode, PS22 firmware and Android USB audio driver.
- Android does not generally let one app inject its processed audio as another app's microphone input. For TikTok, use a supported external hardware loopback/mixer route from the PS22 (or another interface) and verify it with TikTok.
- This starter currently routes the selected/default Oboe input to channel 1; channels 2–8 are virtual playback/mix channels and can be fed by future media/player sources. Android app-to-app capture of protected/ordinary audio is not assumed.
- The app requests RECORD_AUDIO. USB permission/device selection and explicit USB routing can be added after confirming the exact PS22 USB descriptors on the phone.

## Build
1. Install Android Studio (Giraffe or newer) and Android SDK.
2. Open this folder as a project.
3. Let Gradle sync (internet required to fetch Oboe and Android Gradle Plugin).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install on ASUS ROG Phone 2, grant microphone permission, connect PS22 using a data-capable OTG adapter.
6. First test with headphones connected to the interface to avoid acoustic feedback.

Minimum SDK: 26. Target SDK: 35.
