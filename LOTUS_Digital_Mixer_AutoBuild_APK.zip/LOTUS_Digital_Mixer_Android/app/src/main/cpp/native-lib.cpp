#include <jni.h>
#include <oboe/Oboe.h>
#include <array>
#include <atomic>
#include <cmath>
#include <algorithm>
#include <android/log.h>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "LOTUS", __VA_ARGS__)

namespace {
constexpr int kChannels = 8;
struct Channel {
    std::atomic<float> gain{0.75f};
    std::atomic<float> pan{0.0f};
    std::atomic<bool> mute{false};
    std::atomic<bool> solo{false};
    std::atomic<float> lowDb{0.0f}, midDb{0.0f}, highDb{0.0f};
    std::atomic<float> thresholdDb{-18.0f}, ratio{2.0f};
};
std::array<Channel, kChannels> gChannels;
std::atomic<float> gMaster{0.8f};
std::atomic<float> gInputPeak{0.0f}, gOutputPeak{0.0f};
std::atomic<bool> gCreated{false};
std::shared_ptr<oboe::AudioStream> gInput, gOutput;

// Simple one-pole low/high split state for basic tone shaping.
float lowStateL = 0, lowStateR = 0;
float midStateL = 0, midStateR = 0;

float dbToGain(float db) { return std::pow(10.0f, db / 20.0f); }

class InputCallback : public oboe::AudioStreamDataCallback {
public:
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* audioData, int32_t frames) override {
        // Input is consumed by the output callback through a lock-free-ish ring buffer.
        // The ring is intentionally simple and bounded; overflow drops oldest samples.
        const float* in = static_cast<const float*>(audioData);
        const int ch = gInput ? gInput->getChannelCount() : 1;
        for (int i = 0; i < frames; ++i) {
            float l = in[i * ch];
            float r = ch > 1 ? in[i * ch + 1] : l;
            gInputPeak.store(std::max(gInputPeak.load(), std::max(std::abs(l), std::abs(r))));
            push(l, r);
        }
        return oboe::DataCallbackResult::Continue;
    }
    static void push(float l, float r) {
        uint32_t w = writeIndex.load(std::memory_order_relaxed);
        uint32_t next = (w + 1) % kSize;
        uint32_t rd = readIndex.load(std::memory_order_acquire);
        if (next == rd) readIndex.store((rd + 1) % kSize, std::memory_order_release);
        ringL[w] = l; ringR[w] = r;
        writeIndex.store(next, std::memory_order_release);
    }
    static bool pop(float& l, float& r) {
        uint32_t rd = readIndex.load(std::memory_order_relaxed);
        if (rd == writeIndex.load(std::memory_order_acquire)) return false;
        l = ringL[rd]; r = ringR[rd];
        readIndex.store((rd + 1) % kSize, std::memory_order_release);
        return true;
    }
private:
    static constexpr uint32_t kSize = 16384;
    static std::array<float, kSize> ringL, ringR;
    static std::atomic<uint32_t> writeIndex, readIndex;
};
std::array<float, 16384> InputCallback::ringL{};
std::array<float, 16384> InputCallback::ringR{};
std::atomic<uint32_t> InputCallback::writeIndex{0}, InputCallback::readIndex{0};

class OutputCallback : public oboe::AudioStreamDataCallback {
public:
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* audioData, int32_t frames) override {
        float* out = static_cast<float*>(audioData);
        bool anySolo = false;
        for (auto& c : gChannels) anySolo |= c.solo.load();
        float peak = 0.0f;
        for (int i = 0; i < frames; ++i) {
            float inL = 0, inR = 0;
            InputCallback::pop(inL, inR);
            // CH1 currently receives the live hardware input. CH2-CH8 are virtual buses,
            // ready for future media-player/USB/aux sources.
            float mixL = 0, mixR = 0;
            for (int c = 0; c < kChannels; ++c) {
                auto& p = gChannels[c];
                if (p.mute.load() || (anySolo && !p.solo.load())) continue;
                float xL = (c == 0) ? inL : 0.0f;
                float xR = (c == 0) ? inR : 0.0f;
                // Lightweight 3-band tone shaping on the live input channel.
                // Low/mid crossover states are intentionally simple for this first core.
                if (c == 0) {
                    lowStateL += 0.035f * (xL - lowStateL);
                    lowStateR += 0.035f * (xR - lowStateR);
                    midStateL += 0.16f * (xL - midStateL);
                    midStateR += 0.16f * (xR - midStateR);
                    float lowGain = dbToGain(p.lowDb.load());
                    float midGain = dbToGain(p.midDb.load());
                    float highGain = dbToGain(p.highDb.load());
                    xL = lowStateL * lowGain + (midStateL - lowStateL) * midGain + (xL - midStateL) * highGain;
                    xR = lowStateR * lowGain + (midStateR - lowStateR) * midGain + (xR - midStateR) * highGain;
                }
                float gain = p.gain.load();
                float pan = std::clamp(p.pan.load(), -1.0f, 1.0f);
                float leftPan = std::sqrt(0.5f * (1.0f - pan));
                float rightPan = std::sqrt(0.5f * (1.0f + pan));
                // Basic compressor on CH1; threshold and ratio are configurable in native API.
                float mono = 0.5f * (std::abs(xL) + std::abs(xR));
                float levelDb = 20.0f * std::log10(std::max(mono, 1.0e-6f));
                float threshold = p.thresholdDb.load();
                float ratio = std::max(1.0f, p.ratio.load());
                if (levelDb > threshold) {
                    float compressedDb = threshold + (levelDb - threshold) / ratio;
                    gain *= dbToGain(compressedDb - levelDb);
                }
                mixL += xL * gain * leftPan;
                mixR += xR * gain * rightPan;
            }
            float master = gMaster.load();
            float yL = std::tanh(mixL * master);
            float yR = std::tanh(mixR * master);
            out[i * 2] = yL;
            out[i * 2 + 1] = yR;
            peak = std::max(peak, std::max(std::abs(yL), std::abs(yR)));
        }
        gOutputPeak.store(peak);
        return oboe::DataCallbackResult::Continue;
    }
};
std::shared_ptr<InputCallback> gInputCallback = std::make_shared<InputCallback>();
std::shared_ptr<OutputCallback> gOutputCallback = std::make_shared<OutputCallback>();

bool openStreams() {
    oboe::AudioStreamBuilder inBuilder, outBuilder;
    inBuilder.setDirection(oboe::Direction::Input)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Shared)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(2)
        ->setSampleRate(48000)
        ->setDataCallback(gInputCallback);
    oboe::Result r = inBuilder.openStream(gInput);
    if (r != oboe::Result::OK) {
        LOGE("Input stream open failed: %s", oboe::convertToText(r));
        return false;
    }

    outBuilder.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Shared)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(2)
        ->setSampleRate(gInput->getSampleRate())
        ->setDataCallback(gOutputCallback);
    r = outBuilder.openStream(gOutput);
    if (r != oboe::Result::OK) {
        LOGE("Output stream open failed: %s", oboe::convertToText(r));
        gInput->close(); gInput.reset();
        return false;
    }
    return true;
}
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeCreate(JNIEnv*, jobject) {
    if (gCreated.load()) return JNI_TRUE;
    if (!openStreams()) return JNI_FALSE;
    gCreated.store(true);
    return JNI_TRUE;
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeStart(JNIEnv*, jobject) {
    if (!gCreated.load()) return JNI_FALSE;
    auto a = gInput->requestStart();
    auto b = gOutput->requestStart();
    return (a == oboe::Result::OK && b == oboe::Result::OK) ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeStop(JNIEnv*, jobject) {
    if (gInput) { gInput->stop(); gInput->close(); gInput.reset(); }
    if (gOutput) { gOutput->stop(); gOutput->close(); gOutput.reset(); }
    gCreated.store(false);
}
extern "C" JNIEXPORT void JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeSetChannel(JNIEnv*, jobject, jint ch, jfloat gain, jfloat pan, jboolean mute, jboolean solo) {
    if (ch < 0 || ch >= kChannels) return;
    gChannels[ch].gain.store(std::clamp(gain, 0.0f, 1.5f));
    gChannels[ch].pan.store(std::clamp(pan, -1.0f, 1.0f));
    gChannels[ch].mute.store(mute);
    gChannels[ch].solo.store(solo);
}
extern "C" JNIEXPORT void JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeSetEq(JNIEnv*, jobject, jint ch, jfloat low, jfloat mid, jfloat high) {
    if (ch < 0 || ch >= kChannels) return;
    gChannels[ch].lowDb.store(low); gChannels[ch].midDb.store(mid); gChannels[ch].highDb.store(high);
}
extern "C" JNIEXPORT void JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeSetCompressor(JNIEnv*, jobject, jint ch, jfloat threshold, jfloat ratio) {
    if (ch < 0 || ch >= kChannels) return;
    gChannels[ch].thresholdDb.store(threshold); gChannels[ch].ratio.store(std::max(1.0f, ratio));
}
extern "C" JNIEXPORT void JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeSetMaster(JNIEnv*, jobject, jfloat gain) {
    gMaster.store(std::clamp(gain, 0.0f, 1.5f));
}
extern "C" JNIEXPORT jfloat JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeGetInputLevel(JNIEnv*, jobject) { return gInputPeak.exchange(0.0f); }
extern "C" JNIEXPORT jfloat JNICALL
Java_com_lotus_digitalmixer_MainActivity_nativeGetOutputLevel(JNIEnv*, jobject) { return gOutputPeak.load(); }
