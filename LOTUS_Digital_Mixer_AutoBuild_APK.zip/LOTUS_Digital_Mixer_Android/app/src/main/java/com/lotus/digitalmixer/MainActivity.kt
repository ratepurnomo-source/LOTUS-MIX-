package com.lotus.digitalmixer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import android.view.Gravity
import android.graphics.Color
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private external fun nativeCreate(): Boolean
    private external fun nativeStart(): Boolean
    private external fun nativeStop()
    private external fun nativeSetChannel(channel: Int, gain: Float, pan: Float, muted: Boolean, solo: Boolean)
    private external fun nativeSetEq(channel: Int, lowDb: Float, midDb: Float, highDb: Float)
    private external fun nativeSetCompressor(channel: Int, thresholdDb: Float, ratio: Float)
    private external fun nativeSetMaster(gain: Float)
    private external fun nativeGetInputLevel(): Float
    private external fun nativeGetOutputLevel(): Float

    private var running = false
    private val gains = FloatArray(8) { 0.75f }
    private val pans = FloatArray(8) { 0f }
    private val mutes = BooleanArray(8)
    private val solos = BooleanArray(8)
    private var master = 0.8f
    private lateinit var status: TextView
    private lateinit var meters: TextView

    companion object { init { System.loadLibrary("lotus_audio") } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 11)
        }
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(18, 22, 29))
        }
        val title = TextView(this).apply {
            text = "LOTUS DIGITAL MIXER  •  8 CH"
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "ENGINE STOPPED"; textSize = 12f; setTextColor(Color.rgb(80, 205, 235))
            gravity = Gravity.CENTER; setPadding(4, 12, 4, 8)
        }
        meters = TextView(this).apply {
            text = "INPUT  — dBFS      OUTPUT  — dBFS"
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; textSize = 12f
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = Button(this).apply { text = "START AUDIO"; setOnClickListener { startEngine() } }
        val stop = Button(this).apply { text = "STOP"; setOnClickListener { stopEngine() } }
        buttons.addView(start, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(stop, LinearLayout.LayoutParams(0, -2, 1f))

        val masterLabel = TextView(this).apply {
            text = "MASTER LEVEL"; setTextColor(Color.WHITE); setPadding(4, 10, 4, 0)
        }
        val masterSeek = SeekBar(this).apply {
            max = 100; progress = 80
            setOnSeekBarChangeListener(listener { master = it; if (running) nativeSetMaster(master) })
        }

        val channels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (i in 0 until 8) channels.addView(channelPanel(i))

        root.addView(title); root.addView(status); root.addView(meters)
        root.addView(buttons); root.addView(masterLabel); root.addView(masterSeek)
        val scroll = ScrollView(this).apply { addView(channels) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun channelPanel(index: Int): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            setBackgroundColor(if (index % 2 == 0) Color.rgb(31, 38, 48) else Color.rgb(25, 31, 40))
        }
        val label = TextView(this).apply {
            text = "CH ${index + 1}  •  ${if (index == 0) "MIC INPUT" else "VIRTUAL"}"
            setTextColor(Color.WHITE); textSize = 15f
        }
        val gainLabel = TextView(this).apply { text = "LEVEL 75%"; setTextColor(Color.LTGRAY) }
        val gain = SeekBar(this).apply {
            max = 100; progress = 75
            setOnSeekBarChangeListener(listener {
                gains[index] = it
                gainLabel.text = "LEVEL ${(it * 100).toInt()}%"
                applyChannel(index)
            })
        }
        val panLabel = TextView(this).apply { text = "PAN CENTER"; setTextColor(Color.LTGRAY) }
        val pan = SeekBar(this).apply {
            max = 200; progress = 100
            setOnSeekBarChangeListener(listener {
                pans[index] = (it - 100) / 100f
                panLabel.text = when { it < 95 -> "PAN LEFT"; it > 105 -> "PAN RIGHT"; else -> "PAN CENTER" }
                applyChannel(index)
            })
        }
        val toggles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val mute = CheckBox(this).apply {
            text = "MUTE"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked -> mutes[index] = checked; applyChannel(index) }
        }
        val solo = CheckBox(this).apply {
            text = "SOLO"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked -> solos[index] = checked; applyAllChannels() }
        }
        toggles.addView(mute); toggles.addView(solo)
        panel.addView(label); panel.addView(gainLabel); panel.addView(gain)
        panel.addView(panLabel); panel.addView(pan); panel.addView(toggles)
        return panel
    }

    private fun listener(onValue: (Float) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onValue(progress / 100f)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun applyChannel(i: Int) {
        if (running) nativeSetChannel(i, gains[i], pans[i], mutes[i], solos[i])
    }
    private fun applyAllChannels() { for (i in 0 until 8) applyChannel(i) }

    private fun startEngine() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            status.text = "MICROPHONE PERMISSION REQUIRED"; return
        }
        if (!nativeCreate()) { status.text = "AUDIO ENGINE INIT FAILED"; return }
        for (i in 0 until 8) nativeSetChannel(i, gains[i], pans[i], mutes[i], solos[i])
        nativeSetMaster(master)
        running = nativeStart()
        status.text = if (running) "AUDIO ENGINE RUNNING" else "AUDIO START FAILED"
        if (running) updateMeters()
    }

    private fun updateMeters() {
        if (!running) return
        val input = nativeGetInputLevel()
        val output = nativeGetOutputLevel()
        meters.text = "INPUT ${(input.coerceAtLeast(0.00001f).let { 20f * kotlin.math.log10(it) }).toInt()} dBFS     " +
                "OUTPUT ${(output.coerceAtLeast(0.00001f).let { 20f * kotlin.math.log10(it) }).toInt()} dBFS"
        meters.postDelayed({ updateMeters() }, 150)
    }

    private fun stopEngine() {
        nativeStop(); running = false; status.text = "ENGINE STOPPED"
    }

    override fun onDestroy() { stopEngine(); super.onDestroy() }
}
